package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj16WorkingWithCollectionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj16WorkingWithCollectionsApplication.class, args);
	}

}
