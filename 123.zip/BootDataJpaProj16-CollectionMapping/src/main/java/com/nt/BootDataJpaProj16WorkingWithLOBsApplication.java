package com.nt;

public class BootDataJpaProj16WorkingWithLOBsApplication {

}
