package com.nt;

import java.util.Random;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootBatchProj01PocApplication {

	public static void main(String[] args) {
	   SpringApplication.run(BootBatchProj01PocApplication.class, args);
	}//main
}//class
